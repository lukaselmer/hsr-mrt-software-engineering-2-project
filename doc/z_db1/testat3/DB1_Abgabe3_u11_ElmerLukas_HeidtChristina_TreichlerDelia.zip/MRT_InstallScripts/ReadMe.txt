/*
 * Autoren: Delia Treichler, Christina Heidt, Lukas Elmer
 */ 

Um das Skript zu starten:

1. Ins Verzeichnis wechseln, wo sich die entpackte Datei befindet (Bsp: C:\Workspace\MRT_InstallScripts)
2. Folgende Eingabe machen: psql -U postgres -f C:\Workspace\MRT_InstallScripts\0_runAllScripts.sql